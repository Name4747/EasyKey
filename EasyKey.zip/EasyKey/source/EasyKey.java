import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class EasyKey extends PApplet {

JSONArray json;
public String[] recent = {"_","_","_"};
public int n = 0;
public String name = "";
public char rKey = rKey();
public int c = 0xffFFFFFF;
public int g = 0xff000000;
public int right = 0;
public int wrong = 0;

Timer timer = new Timer();
Text start = new Text();
Text score = new Text();
Text keyText = new Text();
Text press = new Text();
Text fscore = new Text();
Text isHighScore = new Text();
Text namePrint = new Text();
Text typeName = new Text();
LeaderBoard leaderBoard = new LeaderBoard();

public void setup() {
  
  frameRate(60);
  json = loadJSONArray("data/data.json");
  leaderBoard.setup();
}

public void draw() {
  PFont f = loadFont("CooperBlack.vlw");
  if (timer.roundEnd == false) {
    background(c); 
    fill(255); strokeWeight(7); rect(width/2-40, height/2-40, 80, 80, 7);//key rectangle
    leaderBoard.draw(f, g);
    /*start text*/start.draw("Press the letter in the center to start!", width/2, height-35, 25, f, g, CENTER, CENTER);
    /*score*/score.draw("Score: "+(right-wrong)*100, 30, 30, 30, f, 0, LEFT, TOP);
    /*timer*/timer.draw(f, leaderBoard);
    /*key text*/keyText.draw(str(rKey), width/2, height/2, 50, f, 0, CENTER, CENTER);
  } 
  else {
    background(255);
    /*press key*/press.draw("Press the SPACE to continue!", width/2, height/2+100, 30, f, 0, CENTER, CENTER);
    /*final score*/fscore.draw("Final Score: "+(right-wrong)*100, width/2, height/2-50, 30, f, 0, CENTER, CENTER);
    /*type name*/typeName.draw("Type name here!", width/2, height/2, 30, f, 0, CENTER, CENTER);
    /*name*/namePrint.draw(recent[0]+recent[1]+recent[2],width/2 ,height/2+45 ,40 ,f ,0 ,CENTER, CENTER);
  }
}

public char rKey() {
  char c = PApplet.parseChar((int)random(97, 122));
  return c;
}

public void resetEverything() {
  c = 0xffFFFFFF;
  g = 0xff000000;
  right = 0;
  wrong = 0;
  name = "";
  n = 0;
  recent[0] = "_";
  recent[1] = "_";
  recent[2] = "_";
  timer.resetTimer();
}

public void resetJSON() {
  for(int i = 0; i < 10; i++) {
      JSONObject obj = json.getJSONObject(i);
      if(i == 0) {
        obj.setInt("score",7000);
        obj.setString("name","dev");
        continue;
      }
      obj.setInt("score",0);
      obj.setString("name","aaa");
    }
  saveJSONArray(json, "data/data.json");
}

public void keyPressed() {
  
  if (timer.roundEnd == false) {
    //startscreen
    if (key == rKey) { 
      timer.timerActive = true;
      c = 0xff1DA00D;
      g = 0xff1DA00D;
      right++;
      rKey = rKey();
    } 
    
    else if(keyCode == 109){
      resetJSON();
    }
    else {
      timer.timerActive = true;
      rKey = rKey();
      c = 0xffCE3A3D;
      g = 0xffCE3A3D;
      wrong++;
    }
  } 
  else {
    //endscreen
    if(PApplet.parseInt(key) >= 97 && PApplet.parseInt(key) <= 122) {
      if (n < 3 && key != 43 && key != 8) {
        recent[n] = str(key);
        n++;
      }
    }
    else if(keyCode == 8 && n > 0) {
      for(int i = 2; i >= 0; i--) {
        if(recent[i] != "_") {
          recent[i] = "_";
          break;
        }
      }
      n--;
    }
  
    if (keyCode == 32) {
      for(String f : recent) {
        if(f == "_") {
          name += "a";
        }
        else {
          name += f;
        }
      }
      if(name.equals("dev")) {
        name = "not";
      }
      leaderBoard.addScore((right-wrong)*100, name);
      leaderBoard.saveJSON();
      resetEverything();
    }
  }
}
public class LeaderBoard {
  public Score[] arr = new Score[10];
  public int x = 30;
  public int y = 140;
  Text text = new Text();
  Text nums = new Text();
  
  public void setup() {
    for(int i = 0; i < arr.length; i++) {
      JSONObject obj = json.getJSONObject(i);
      Score scr = new Score(obj.getInt("score"), obj.getString("name"));
      arr[i] = scr;
    }
  }
  
  public void draw(PFont f, int c) {
    text.draw("Leaderboard:", 30, 100, 20, f, c, LEFT, TOP);
    for(int i = 0; i < 10; i++) {
      nums.draw((i+1)+". "+arr[i].name+" "+arr[i].score, x, y+(i*40), 20, f, c, LEFT, TOP);
    }
  }
  
  public void saveJSON() {
    for(int i = 0; i < arr.length; i++) {
      JSONObject obj = json.getJSONObject(i);
      obj.setInt("score",arr[i].score);
      obj.setString("name",arr[i].name);
    }
    saveJSONArray(json, "data/data.json");
  }
  
  public void addScore(int score, String name) {
    for(int i = 0; i < arr.length; i++) {
      if(score > arr[i].score) {
        Score temp = arr[i];
        Score temp2;
        for(int j = i; j < arr.length; j++) {
          if (j < arr.length - 1) {
            temp2 = arr[j+1];
            arr[j+1] = temp;
            temp = temp2;
          }
        }
        Score scr = new Score(score, name);
        arr[i] = scr;
        
        break;
      }
    }
  }
  
}
public class Score {
  public int score;
  public String name;
  
  public Score(int score, String name) {
    this.score = score;
    this.name = name;
  }
}
public class Text {
  public Text() { 
  }
  
  public void draw(String text, int x, int y, int size, PFont f, int c, int hAlign, int vAlign) {
    textFont(f);
    fill(c);
    textSize(size);
    textAlign(hAlign,vAlign);
    text(text,x,y);
  }
}
public class Timer {
  public boolean timerActive;
  public boolean roundEnd = false;
  public int time;
  public int timeLength = 60;
  
  public Timer() {
    this.timerActive = false;
    this.time = timeLength;
  }
  
  public void draw(PFont f, LeaderBoard leaderBoard) {
    textFont(f); fill(0); textSize(30); textAlign(LEFT,TOP); text("Timer: "+time,405,30);/*timer*/
    if(timerActive) {
      if(time == 0) {
        timerActive = false;
        roundEnd = true;
        //leaderBoard.addScore((right-wrong)*100, name);
      }
      else if((frameCount % 60) == 0) {
        time--;
      }
    }
  }
  
  public void resetTimer() {
    timerActive = false;
    time = timeLength;
    roundEnd = false;
  }
}
  public void settings() {  size(600, 600); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "EasyKey" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
